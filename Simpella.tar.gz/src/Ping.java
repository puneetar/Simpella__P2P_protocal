import java.io.Serializable;


public class Ping extends Message{

	public Ping() {
		
		super((byte)0x00);
	}

	

}
